from django.contrib import admin
from .models import *
from django import forms

# Register your models here.

class BlogdataAdmin(admin.ModelAdmin):
    list_display=['user','title','content','publish_date']
admin.site.register(Blogdata,BlogdataAdmin)
