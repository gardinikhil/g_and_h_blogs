from django.contrib import admin
from django.urls import path,include
from myapp import views

urlpatterns = [
    path('',views.home),
    path('login',views.loginuser),
    path('logout',views.logoutuser),
    path('signup',views.signupuser),
    path('myblog',views.showmyblog),
    path('othersblog',views.showothersblog),
    path('show/<int:id>',views.show),
    path('update/<int:id>',views.update),
    path('delete/<int:id>',views.delete),

]