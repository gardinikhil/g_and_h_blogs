from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import logout,authenticate,login
from .forms import *
from .models import *
from django.contrib import messages

# Create your views here.

def home(request):
    if request.user.is_anonymous:
        return redirect('/login')

    if request.method=="POST":
        form=BlogdataForm(request.POST or None)
        if form.is_valid():
            m = form.save(commit=False)
            m.user = request.user
            m.save() 
            messages.success(request, 'Blog Posted successfully!!')
            return redirect('/')

    else: 
        form=BlogdataForm()       
    return render(request,'myapp/home.html',{'form':form,'user':request.user})

def loginuser(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            # A backend authenticated the credentials
            login(request,user)
            return redirect('/')
        else:
            # No backend authenticated the credentials
            messages.warning(request, 'Wrong password!!!') 
            return render(request,'myapp/login.html')

    return render(request,'myapp/login.html')


def logoutuser(request):
    logout(request)
    return redirect('/login')   

def signupuser(request):
    if request.method=="POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password1 == password2 :
            if User.objects.filter(username=username).exists():
                messages.warning(request, 'Username is already taken!!') 
                return redirect('/')
            elif User.objects.filter(email=email).exists():  
                messages.warning(request, 'Email is already taken!!') 
                return redirect('/')
            else:    
                new_user=User.objects.create_user(first_name=first_name,last_name=last_name,username=username,password=password2,email=email)
                new_user.save()
                messages.success(request, 'Account created successfully!')
                return redirect('/')

        else:
            messages.warning(request, 'Password did not match!!') 
            return render(request,'/')     

    return render(request,'myapp/signup.html')  


def showmyblog(request):
    obj=Blogdata.objects.filter(user=request.user)

    return render(request,'myapp/showmyblog1.html',{'obj':obj})

def showothersblog(request):
    obj=Blogdata.objects.exclude(user=request.user)

    return render(request,'myapp/showothersblog1.html',{'obj':obj})   


def show(request,id):
    obj=Blogdata.objects.get(id=id)

    return render(request,'myapp/show.html',{'obj':obj})


def update(request,id):
    obj=Blogdata.objects.get(id=id)

    form=BlogdataForm(request.POST or None,instance=obj)
    if form.is_valid():
        form.save() 
        messages.success(request, 'Blog updated successfully!!')
        return redirect('/')

    return render(request,'myapp/update.html',{'form':form,'id':id})


def delete(request,id):

    obj = Blogdata.objects.get(id=id)

    obj.delete()

    return redirect('/')    